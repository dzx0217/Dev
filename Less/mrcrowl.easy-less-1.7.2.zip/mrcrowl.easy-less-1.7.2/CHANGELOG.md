![Easy LESS logo](https://github.com/mrcrowl/vscode-easy-less/raw/master/./icon.png)

## The [Easy LESS changelog](https://playbooks.codelingo.io/p/p_EMdmk2e) can now be found on CodeLingo Playbooks.
